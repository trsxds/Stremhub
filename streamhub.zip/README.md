# StreamHub — Streaming Service with WebTorrent

## ⚠️ Честные ограничения

| Проблема | Решение |
|---|---|
| **GitHub Actions + Jackett** | IP GitHub забанены на 90% трекеров. Используйте домашний сервер/VPS с cron вместо GitHub Actions, или ручной импорт через API. |
| **Render Free спит** | Зарегистрируйтесь на [uptimerobot.com](https://uptimerobot.com) и пингуйте `/health` каждые 5 минут. |
| **WebTorrent на Render** | Работает, но диск эфемерный. После сна торренты начинают качаться заново. Для стабильности — VPS с постоянным диском. |
| **MKV в браузере** | Не играет напрямую. MP4/WebM — работают. Для MKV используйте кнопку «VLC». |
| **Dolby Atmos в браузере** | Браузеры не поддерживают bitstream HD-audio. Метаданные отображаются, но звук будет обычным AAC/AC3. |

## Быстрый старт (5 шагов)

### 1. Создать репозиторий
```bash
git init
git add .
git commit -m "init"
git branch -M main
git remote add origin https://github.com/YOURNAME/streamhub.git
git push -u origin main
```

### 2. Supabase
- [supabase.com](https://supabase.com) → New Project
- SQL Editor → запустить `database/migrations.sql`
- Settings → API → скопировать `Project URL` и `anon public` key

### 3. Deploy на Render
- [render.com](https://render.com) → New Web Service → Connect GitHub repo
- Build Command: `cd backend && npm install`
- Start Command: `cd backend && npm start`
- Environment Variables:
  - `SUPABASE_URL` — из шага 2
  - `SUPABASE_KEY` — из шага 2
  - `JWT_SECRET` — случайная строка (генератор: `openssl rand -base64 32`)
  - `ENABLE_CRON` — `false` (если не хотите парсинг на Render)

### 4. Не дать уснуть
- [uptimerobot.com](https://uptimerobot.com) → Add Monitor
- URL: `https://your-app.onrender.com/health`
- Interval: 5 minutes

### 5. Парсинг (выберите один вариант)

**Вариант А — GitHub Actions (может не работать с трекерами):**
- Settings → Secrets → добавьте `SUPABASE_URL`, `SUPABASE_KEY`, `JACKETT_URL`, `JACKETT_API_KEY`
- Actions → Parser → Run workflow

**Вариант Б — Домашний сервер/VPS (надёжно):**
```bash
# Установите Node.js 18+
cd backend
npm install
# Создайте .env файл
# Запустите парсер вручную:
node -e "require('dotenv').config(); const {createClient}=require('@supabase/supabase-js'); const supabase=createClient(process.env.SUPABASE_URL,process.env.SUPABASE_KEY); /* ... parser code ... */"
# Или добавьте в crontab:
# 0 */6 * * * cd /path/to/streamhub/backend && node parser.js
```

**Вариант В — Ручное добавление (если нет Jackett):**
Используйте SQL-запросы в Supabase SQL Editor:
```sql
INSERT INTO content (title, type, year, quality, magnet_link, genres, description)
VALUES ('Название фильма', 'movie', 2024, '1080p', 'magnet:?xt=urn:btih:...', ARRAY['боевик'], 'Описание');
```

## Как работает стриминг

1. Пользователь кликает фильм
2. Фронтенд открывает плеер и запрашивает `/api/stream?magnet=...`
3. Бэкенд (WebTorrent) подключается к пирам и начинает скачивать
4. Браузер получает видео-поток через HTTP Range requests (перемотка работает)
5. Прогресс отображается в плеере

## Структура
```
streamhub/
├── backend/
│   ├── package.json
│   └── server.js          # ← всё в одном файле: API + WebTorrent + Auth
├── frontend/
│   ├── index.html
│   ├── css/style.css
│   └── js/app.js          # ← всё в одном файле: UI + плеер + API
├── database/migrations.sql
└── .github/workflows/parser.yml
```

## API Endpoints
- `POST /api/auth/register` — регистрация
- `POST /api/auth/login` — вход
- `GET /api/content` — каталог (query: type, quality, year, search, page, limit)
- `GET /api/content/:id` — детали
- `GET /api/stream?magnet=...` — **стриминг торрента**
- `GET /api/stream/status?magnet=...` — статус загрузки
- `GET /api/social/profile` — профиль
- `POST /api/social/invite` — пригласить друга

## Лицензия
Только для образовательных целей.
