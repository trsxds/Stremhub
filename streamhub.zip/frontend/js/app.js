const API = '';
let token = localStorage.getItem('token');

// ===== API =====
async function api(url, opts = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers['Authorization'] = `Bearer ${token}`;
  const res = await fetch(`${API}${url}`, { ...opts, headers: { ...headers, ...opts.headers } });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

// ===== TOAST =====
function toast(msg, type = 'success') {
  const c = document.getElementById('toastContainer');
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.textContent = msg;
  c.appendChild(t);
  setTimeout(() => t.remove(), 4000);
}

// ===== APP =====
const app = {
  page: 1,
  filters: {},
  currentContent: null,
  statusInterval: null,

  init() {
    this.bindEvents();
    this.checkAuth();
    this.loadCarousels();
    this.loadCatalog();
    this.handleInvite();
    window.addEventListener('scroll', () => {
      document.querySelector('.navbar').classList.toggle('scrolled', window.scrollY > 50);
    });
  },

  bindEvents() {
    // Auth modal
    document.getElementById('authBtn').onclick = () => document.getElementById('authModal').classList.remove('hidden');
    document.querySelector('#authModal .modal-close').onclick = () => document.getElementById('authModal').classList.add('hidden');

    let isReg = false;
    document.getElementById('toggleAuth').onclick = (e) => {
      e.preventDefault();
      isReg = !isReg;
      document.getElementById('authTitle').textContent = isReg ? 'Регистрация' : 'Вход';
      document.getElementById('authSubmit').textContent = isReg ? 'Зарегистрироваться' : 'Войти';
      document.getElementById('toggleAuth').textContent = isReg ? 'Войти' : 'Зарегистрироваться';
      document.querySelector('.auth-toggle').firstChild.textContent = isReg ? 'Уже есть аккаунт? ' : 'Нет аккаунта? ';
    };

    document.getElementById('authForm').onsubmit = async (e) => {
      e.preventDefault();
      const email = document.getElementById('authEmail').value;
      const password = document.getElementById('authPassword').value;
      try {
        const data = await api(isReg ? '/api/auth/register' : '/api/auth/login', {
          method: 'POST', body: JSON.stringify({ email, password })
        });
        token = data.token;
        localStorage.setItem('token', token);
        document.getElementById('authModal').classList.add('hidden');
        toast(isReg ? 'Регистрация успешна!' : 'Добро пожаловать!');
        this.checkAuth();
      } catch (err) { toast(err.message, 'error'); }
    };

    document.getElementById('logoutBtn').onclick = () => {
      token = null; localStorage.removeItem('token');
      this.checkAuth(); toast('Вы вышли');
    };

    // Player close
    document.querySelector('#playerModal .modal-close').onclick = () => this.closePlayer();

    // Nav
    document.querySelectorAll('.nav-links a').forEach(link => {
      link.onclick = (e) => {
        e.preventDefault();
        const section = link.dataset.section;
        document.querySelectorAll('.nav-links a').forEach(l => l.classList.remove('active'));
        link.classList.add('active');
        if (section === 'social') {
          document.getElementById('mainContent').classList.add('hidden');
          document.getElementById('socialPage').classList.remove('hidden');
          this.loadSocial();
        } else {
          document.getElementById('mainContent').classList.remove('hidden');
          document.getElementById('socialPage').classList.add('hidden');
          this.filters.type = section === 'home' ? '' : section;
          this.page = 1; this.loadCatalog();
        }
      };
    });

    // Search
    let st;
    document.getElementById('searchInput').oninput = (e) => {
      clearTimeout(st);
      st = setTimeout(() => this.handleSearch(e.target.value), 300);
    };

    // Filters
    document.getElementById('filterToggle').onclick = () => document.getElementById('filtersSidebar').classList.toggle('hidden');
    document.getElementById('applyFilters').onclick = () => {
      const q = [...document.querySelectorAll('.filter-quality:checked')].map(c => c.value);
      const t = [...document.querySelectorAll('.filter-type:checked')].map(c => c.value);
      this.filters = { ...this.filters, quality: q[0] || '', type: t[0] || this.filters.type, year: document.getElementById('filterYear').value, rating: document.getElementById('filterRating').value };
      this.page = 1; this.loadCatalog();
    };
  },

  async checkAuth() {
    if (token) {
      document.getElementById('authBtn').classList.add('hidden');
      document.getElementById('userMenu').classList.remove('hidden');
      try {
        await api('/api/social/profile');
        document.getElementById('userEmail').textContent = 'Аккаунт';
        document.getElementById('friendsSection').style.display = 'block';
      } catch { token = null; localStorage.removeItem('token'); }
    } else {
      document.getElementById('authBtn').classList.remove('hidden');
      document.getElementById('userMenu').classList.add('hidden');
      document.getElementById('friendsSection').style.display = 'none';
    }
  },

  async handleSearch(q) {
    const el = document.getElementById('searchSuggestions');
    if (q.length < 2) { el.innerHTML = ''; return; }
    try {
      const res = await api(`/api/content/search/suggest?q=${encodeURIComponent(q)}`);
      el.innerHTML = res.map(r => `<div class="suggestion-item" onclick="app.openContent('${r.id}')">
        <img src="${r.poster_url || 'https://via.placeholder.com/40x60'}" alt="">
        <div><div>${r.title}</div><small>${r.year} • ${r.type}</small></div>
      </div>`).join('');
    } catch { el.innerHTML = ''; }
  },

  async loadCarousels() {
    try {
      const [n4k, anime] = await Promise.all([api('/api/content/carousel/new4k'), api('/api/content/carousel/anime')]);
      this.renderCarousel('new4kCarousel', n4k);
      this.renderCarousel('animeCarousel', anime);
    } catch(e) { console.error(e); }
  },

  renderCarousel(id, items) {
    document.getElementById(id).innerHTML = items.map(i => this.card(i)).join('');
  },

  card(item) {
    const icons = (item.audio_tracks || []).map(t => {
      if (t.channels === 'mono') return '🔇';
      if (t.channels === '5.1') return '🎧';
      if (t.channels === '7.1' || t.codec?.includes('Atmos')) return '🎵';
      return '🔊';
    }).join(' ');
    return `<div class="card" onclick="app.openContent('${item.id}')">
      <img src="${item.poster_url || 'https://via.placeholder.com/240x360?text=No+Poster'}" alt="${item.title}" loading="lazy">
      <div class="card-overlay">
        <div class="card-title">${item.title}</div>
        <div class="card-meta"><span class="quality-badge">${item.quality}</span><span>${item.year || ''}</span><span>⭐${item.imdb_rating || '-'}</span></div>
        <div class="audio-icons">${icons}</div>
      </div>
    </div>`;
  },

  async loadCatalog() {
    try {
      const params = new URLSearchParams({ page: this.page, limit: 20, ...this.filters });
      const res = await api(`/api/content?${params}`);
      document.getElementById('catalogGrid').innerHTML = res.data.map(i => this.card(i)).join('');
      this.renderPagination(res.page, res.limit, res.data.length);
    } catch(e) { console.error(e); }
  },

  renderPagination(page, limit, count) {
    let h = '';
    if (page > 1) h += `<button onclick="app.goPage(${page - 1})">← Назад</button>`;
    h += `<button class="active">${page}</button>`;
    if (count === limit) h += `<button onclick="app.goPage(${page + 1})">Вперёд →</button>`;
    document.getElementById('pagination').innerHTML = h;
  },

  goPage(p) { this.page = p; this.loadCatalog(); window.scrollTo({ top: document.getElementById('catalogSection').offsetTop - 80, behavior: 'smooth' }); },

  // ===== PLAYER с WebTorrent-стримингом =====
  async openContent(id) {
    try {
      const c = await api(`/api/content/${id}`);
      this.currentContent = c;
      document.getElementById('playerModal').classList.remove('hidden');
      const video = document.getElementById('videoPlayer');
      const statusEl = document.getElementById('torrentStatus');
      const bar = document.getElementById('torrentBar');
      const text = document.getElementById('torrentText');

      // Метаданные
      document.getElementById('contentMeta').innerHTML = `
        <h3>${c.title}</h3>
        <div class="meta-row">
          <span>${c.year || ''}</span>
          <span class="quality-badge">${c.quality}</span>
          <span>⭐ ${c.imdb_rating || 'N/A'}</span>
          <span>${c.type === 'movie' ? 'Фильм' : c.type === 'series' ? 'Сериал' : 'Аниме'}</span>
        </div>
        <div class="meta-row">${(c.genres || []).map(g => `<span>${g}</span>`).join(' • ')}</div>
        <p class="description">${c.description || 'Описание отсутствует'}</p>
      `;

      // Аудио
      const ai = document.getElementById('audioInfo');
      if (c.audio_tracks?.length) {
        ai.innerHTML = c.audio_tracks.map((t, i) => {
          let icon = '🔊';
          if (t.channels === 'mono') icon = '🔇';
          else if (t.channels === '5.1') icon = '🎧';
          else if (t.channels === '7.1' || t.codec?.includes('Atmos')) icon = '🎵';
          return `<div class="audio-track ${t.is_default ? 'active' : ''}">${icon} ${t.language} ${t.codec} ${t.channels} ${t.studio ? '(' + t.studio + ')' : ''}</div>`;
        }).join('');
      } else ai.innerHTML = '<div class="audio-track">🔊 Оригинал</div>';

      // Кнопки
      document.getElementById('btnMagnet').onclick = () => {
        if (c.magnet_link) window.open(c.magnet_link, '_blank');
        else toast('Magnet недоступен', 'error');
      };
      document.getElementById('btnVLC').onclick = () => {
        if (c.magnet_link) window.open(`vlc://${c.magnet_link}`, '_self');
      };
      document.getElementById('btnAddList').onclick = async () => {
        try {
          await api('/api/social/list', { method: 'POST', body: JSON.stringify({ list_type: 'watching', content_id: c.id }) });
          toast('Добавлено в «Смотрю сейчас»');
          await api('/api/social/activity', { method: 'POST', body: JSON.stringify({ content_id: c.id, action: 'started', quality: c.quality, studio: c.audio_tracks?.[0]?.studio }) });
        } catch { toast('Войдите, чтобы добавлять в список', 'error'); }
      };

      // ===== СТРИМИНГ ЧЕРЕЗ БЭКЕНД =====
      if (c.magnet_link) {
        // Показываем статус
        statusEl.classList.remove('hidden');
        bar.style.width = '0%';
        text.textContent = 'Подключение к пирам...';

        // Запускаем polling статуса
        if (this.statusInterval) clearInterval(this.statusInterval);
        this.statusInterval = setInterval(async () => {
          try {
            const st = await fetch(`${API}/api/stream/status?magnet=${encodeURIComponent(c.magnet_link)}`).then(r => r.json());
            if (st.active) {
              bar.style.width = st.progress + '%';
              const speed = (st.downloadSpeed / 1024 / 1024).toFixed(1);
              text.textContent = `${st.progress}% • ${speed} MB/s • ${st.numPeers} пиров`;
              if (st.progress > 2 && video.paused && !video.src) {
                // Достаточно буфера — запускаем
                video.src = `${API}/api/stream?magnet=${encodeURIComponent(c.magnet_link)}`;
                video.play().catch(() => {});
                statusEl.classList.add('hidden');
              }
            }
          } catch {}
        }, 2000);

        // Первоначальная попытка через 3 сек
        setTimeout(() => {
          if (!video.src) {
            video.src = `${API}/api/stream?magnet=${encodeURIComponent(c.magnet_link)}`;
            video.play().catch(() => {});
          }
        }, 3000);
      } else {
        statusEl.classList.remove('hidden');
        text.textContent = 'Magnet-ссылка отсутствует';
        video.poster = c.poster_url || '';
      }
    } catch(e) { toast('Ошибка загрузки', 'error'); }
  },

  closePlayer() {
    const video = document.getElementById('videoPlayer');
    video.pause(); video.src = ''; video.load();
    if (this.statusInterval) { clearInterval(this.statusInterval); this.statusInterval = null; }
    document.getElementById('playerModal').classList.add('hidden');
    document.getElementById('torrentStatus').classList.add('hidden');
  },

  // ===== SOCIAL =====
  async loadSocial() {
    try {
      const [profile, activity, leaderboard] = await Promise.all([
        api('/api/social/profile'), api('/api/social/activity'), api('/api/social/leaderboard')
      ]);
      document.getElementById('statWatching').textContent = (profile.watching || []).length;
      document.getElementById('statWatched').textContent = (profile.watched || []).length;
      document.getElementById('statWatchlist').textContent = (profile.watchlist || []).length;

      document.getElementById('activityList').innerHTML = (activity || []).length ? activity.map(a =>
        `<div class="activity-item"><strong>${a.users?.email || 'Пользователь'}</strong> ${a.action === 'started' ? 'начал смотреть' : 'посмотрел'} <strong>${a.content?.title || 'фильм'}</strong> ${a.quality ? `в ${a.quality}` : ''} ${a.studio ? `с озвучкой ${a.studio}` : ''}</div>`
      ).join('') : '<p style="color:var(--text-secondary)">Пока нет активности</p>';

      document.getElementById('leaderboardList').innerHTML = leaderboard.map((u, i) =>
        `<div class="leaderboard-item"><span><span class="rank">#${i + 1}</span> ${u.email}</span><span>${u.watched_count} просмотров</span></div>`
      ).join('');

      document.getElementById('btnInvite').onclick = async () => {
        const res = await api('/api/social/invite', { method: 'POST' });
        const el = document.getElementById('inviteResult');
        el.classList.remove('hidden');
        el.innerHTML = `<strong>Ссылка для друга:</strong><br><a href="${res.inviteUrl}" target="_blank">${res.inviteUrl}</a>`;
      };
    } catch(e) { console.error(e); }
  },

  async handleInvite() {
    const code = new URLSearchParams(window.location.search).get('invite');
    if (code && token) {
      try { await api('/api/social/accept-invite', { method: 'POST', body: JSON.stringify({ code }) }); toast('Вы добавлены в друзья!'); window.history.replaceState({}, '', '/'); }
      catch { toast('Не удалось принять приглашение', 'error'); }
    }
  }
};

document.addEventListener('DOMContentLoaded', () => app.init());
