require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { createClient } = require('@supabase/supabase-js');
const WebTorrent = require('webtorrent');
const rangeParser = require('range-parser');
const mime = require('mime');
const cron = require('node-cron');

// ===== ИНИЦИАЛИЗАЦИЯ =====
const app = express();
app.use(cors());
app.use(express.json());

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);
const wtClient = new WebTorrent({
  dht: true,
  tracker: true,
  webSeeds: true
});

// Хранилище активных торрентов (infoHash -> torrent)
const activeTorrents = new Map();

// ===== МИДДЛВАРЫ =====
const auth = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Требуется авторизация' });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch { res.status(401).json({ error: 'Неверный токен' }); }
};

// ===== СТАТИКА =====
app.use(express.static(path.join(__dirname, '../frontend')));

// ===== HEALTH CHECK =====
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString(), uptime: process.uptime() });
});

// ===== AUTH =====
app.post('/api/auth/register', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password || password.length < 6) {
    return res.status(400).json({ error: 'Email и пароль (мин. 6 символов) обязательны' });
  }
  const hash = await bcrypt.hash(password, 10);
  const { data: user, error } = await supabase.from('users').insert([{ email, password_hash: hash }]).select().single();
  if (error) return res.status(400).json({ error: 'Пользователь уже существует' });
  await supabase.from('profiles').insert([{ user_id: user.id }]);
  const token = jwt.sign({ userId: user.id, email }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, email } });
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  const { data: user } = await supabase.from('users').select('*').eq('email', email).single();
  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    return res.status(401).json({ error: 'Неверный email или пароль' });
  }
  const token = jwt.sign({ userId: user.id, email }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, email } });
});

// ===== CONTENT =====
app.get('/api/content', async (req, res) => {
  const { type, genre, year, quality, search, page = 1, limit = 20 } = req.query;
  let q = supabase.from('content').select('*, audio_tracks(*), subtitles(*)')
    .order('created_at', { ascending: false })
    .range((page - 1) * limit, page * limit - 1);
  if (type) q = q.eq('type', type);
  if (genre) q = q.contains('genres', [genre]);
  if (year) q = q.eq('year', year);
  if (quality) q = q.eq('quality', quality);
  if (search) q = q.ilike('title', `%${search}%`);
  const { data, error } = await q;
  if (error) return res.status(500).json({ error: error.message });
  res.json({ data, page: parseInt(page), limit: parseInt(limit) });
});

app.get('/api/content/:id', async (req, res) => {
  const { data, error } = await supabase.from('content').select('*, audio_tracks(*), subtitles(*)').eq('id', req.params.id).single();
  if (error || !data) return res.status(404).json({ error: 'Не найдено' });
  res.json(data);
});

app.get('/api/content/search/suggest', async (req, res) => {
  const { q } = req.query;
  if (!q || q.length < 2) return res.json([]);
  const { data } = await supabase.from('content').select('id, title, year, type, poster_url').ilike('title', `%${q}%`).limit(10);
  res.json(data || []);
});

app.get('/api/content/carousel/new4k', async (req, res) => {
  const { data } = await supabase.from('content').select('*').eq('quality', '4K').order('created_at', { ascending: false }).limit(20);
  res.json(data || []);
});

app.get('/api/content/carousel/anime', async (req, res) => {
  const { data } = await supabase.from('content').select('*').eq('type', 'anime').order('created_at', { ascending: false }).limit(20);
  res.json(data || []);
});

// ===== WEBTORRENT STREAMING =====
// Извлекаем infoHash из magnet-ссылки
function extractInfoHash(magnet) {
  const match = magnet.match(/xt=urn:btih:([a-fA-F0-9]{40})/);
  return match ? match[1].toLowerCase() : null;
}

// Находим видео-файл в торренте
function findVideoFile(torrent) {
  const exts = ['.mp4', '.webm', '.mkv', '.avi', '.mov', '.m4v'];
  return torrent.files.find(f => exts.some(e => f.name.toLowerCase().endsWith(e)));
}

// Стриминг торрента
app.get('/api/stream', async (req, res) => {
  const magnet = req.query.magnet;
  if (!magnet) return res.status(400).json({ error: 'magnet обязателен' });

  const infoHash = extractInfoHash(magnet);
  if (!infoHash) return res.status(400).json({ error: 'Невалидная magnet-ссылка' });

  let torrent = activeTorrents.get(infoHash);

  if (!torrent) {
    console.log(`⬇️ Добавляем торрент: ${infoHash}`);
    torrent = wtClient.add(magnet, { announce: [
      'udp://tracker.opentrackr.org:1337/announce',
      'udp://tracker.openbittorrent.com:6969/announce',
      'udp://tracker.torrent.eu.org:451/announce'
    ]});
    activeTorrents.set(infoHash, torrent);

    // Очистка через 2 часа неактивности
    setTimeout(() => {
      if (activeTorrents.has(infoHash)) {
        console.log(`🗑️ Удаляем торрент: ${infoHash}`);
        wtClient.remove(infoHash);
        activeTorrents.delete(infoHash);
      }
    }, 2 * 60 * 60 * 1000);
  }

  // Ждём готовности
  if (!torrent.files.length) {
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Timeout')), 30000);
      torrent.on('ready', () => { clearTimeout(timeout); resolve(); });
      torrent.on('error', (e) => { clearTimeout(timeout); reject(e); });
    });
  }

  const file = findVideoFile(torrent);
  if (!file) return res.status(404).json({ error: 'Видео-файл не найден в торренте' });

  const fileSize = file.length;
  const range = req.headers.range;
  const mimeType = mime.getType(file.name) || 'video/mp4';

  if (!range) {
    res.setHeader('Content-Type', mimeType);
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Content-Length', fileSize);
    file.createReadStream().pipe(res);
  } else {
    const ranges = rangeParser(fileSize, range, { combine: true });
    if (ranges === -1 || ranges === -2) {
      res.status(416).setHeader('Content-Range', `bytes */${fileSize}`).end();
      return;
    }
    const { start, end } = ranges[0];
    const chunkSize = end - start + 1;
    res.status(206);
    res.setHeader('Content-Range', `bytes ${start}-${end}/${fileSize}`);
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Content-Length', chunkSize);
    res.setHeader('Content-Type', mimeType);
    file.createReadStream({ start, end }).pipe(res);
  }
});

// Статус торрента (seeders, progress)
app.get('/api/stream/status', (req, res) => {
  const magnet = req.query.magnet;
  if (!magnet) return res.json({});
  const infoHash = extractInfoHash(magnet);
  const torrent = activeTorrents.get(infoHash);
  if (!torrent) return res.json({ active: false });
  res.json({
    active: true,
    progress: Math.round(torrent.progress * 100),
    downloadSpeed: torrent.downloadSpeed,
    uploadSpeed: torrent.uploadSpeed,
    numPeers: torrent.numPeers,
    done: torrent.done
  });
});

// ===== SOCIAL =====
app.get('/api/social/profile', auth, async (req, res) => {
  const { data } = await supabase.from('profiles').select('*').eq('user_id', req.user.userId).single();
  res.json(data);
});

app.post('/api/social/list', auth, async (req, res) => {
  const { list_type, content_id } = req.body;
  const { data: profile } = await supabase.from('profiles').select(list_type).eq('user_id', req.user.userId).single();
  const current = profile?.[list_type] || [];
  const updated = current.includes(content_id) ? current.filter(id => id !== content_id) : [...current, content_id];
  await supabase.from('profiles').update({ [list_type]: updated }).eq('user_id', req.user.userId);
  res.json({ [list_type]: updated });
});

app.get('/api/social/activity', auth, async (req, res) => {
  const { data: friends } = await supabase.from('friendships').select('friend_id').eq('user_id', req.user.userId).eq('status', 'accepted');
  const ids = friends?.map(f => f.friend_id) || [];
  if (!ids.length) return res.json([]);
  const { data } = await supabase.from('activity_log').select('*, content(title, poster_url), users(email)').in('user_id', ids).order('timestamp', { ascending: false }).limit(50);
  res.json(data || []);
});

app.post('/api/social/activity', auth, async (req, res) => {
  const { content_id, action, quality, studio } = req.body;
  await supabase.from('activity_log').insert([{ user_id: req.user.userId, content_id, action, quality, studio, timestamp: new Date().toISOString() }]);
  res.json({ ok: true });
});

app.post('/api/social/invite', auth, async (req, res) => {
  const code = Math.random().toString(36).substring(2, 10);
  await supabase.from('friendships').insert([{ user_id: req.user.userId, invite_code: code, status: 'pending' }]);
  const inviteUrl = `${req.protocol}://${req.get('host')}/?invite=${code}`;
  res.json({ inviteUrl, code });
});

app.post('/api/social/accept-invite', auth, async (req, res) => {
  const { code } = req.body;
  const { data: invite } = await supabase.from('friendships').select('*').eq('invite_code', code).single();
  if (!invite) return res.status(404).json({ error: 'Код не найден' });
  await supabase.from('friendships').insert([{ user_id: req.user.userId, friend_id: invite.user_id, status: 'accepted' }]);
  await supabase.from('friendships').update({ friend_id: req.user.userId, status: 'accepted' }).eq('id', invite.id);
  res.json({ ok: true });
});

app.get('/api/social/leaderboard', auth, async (req, res) => {
  const { data: friends } = await supabase.from('friendships').select('friend_id').eq('user_id', req.user.userId).eq('status', 'accepted');
  const ids = [req.user.userId, ...(friends?.map(f => f.friend_id) || [])];
  const { data } = await supabase.from('profiles').select('user_id, watched, users(email)').in('user_id', ids);
  const ranked = (data || []).map(p => ({ user_id: p.user_id, email: p.users?.email, watched_count: (p.watched || []).length })).sort((a, b) => b.watched_count - a.watched_count);
  res.json(ranked);
});

// ===== PARSER (для cron) =====
async function runParser() {
  console.log('⏰ Запуск парсера...');
  try {
    const axios = require('axios');
    const jackettUrl = process.env.JACKETT_URL;
    const apiKey = process.env.JACKETT_API_KEY;
    if (!jackettUrl || !apiKey) { console.log('⚠️ Jackett не настроен'); return; }

    const response = await axios.get(`${jackettUrl}/api/v2.0/indexers/all/results`, {
      params: { apikey: apiKey, Query: 'movie', Category: [2000, 5000], Limit: 100 },
      timeout: 30000
    });

    const results = response.data.Results || [];
    console.log(`📥 Получено ${results.length} релизов`);

    for (const item of results) {
      const title = item.Title.replace(/\.\w{3,4}$/, '').replace(/\./g, ' ').trim();
      const lower = title.toLowerCase();
      const type = lower.includes('s0') || lower.includes('season') || lower.includes('сезон') ? 'series' :
                   lower.includes('anime') ? 'anime' : 'movie';
      const quality = lower.includes('2160p') || lower.includes('4k') ? '4K' :
                      lower.includes('1080p') ? '1080p' :
                      lower.includes('720p') ? '720p' : 'unknown';
      const yearMatch = title.match(/\b(19|20)\d{2}\b/);
      const year = yearMatch ? parseInt(yearMatch[0]) : null;
      const magnet = item.MagnetUri || item.Link;

      const { data: existing } = await supabase.from('content').select('id').eq('magnet_link', magnet).single();
      if (existing) continue;

      const { data: content } = await supabase.from('content').insert([{
        title, type, year, quality, magnet_link: magnet, size: item.Size,
        seeders: item.Seeders, peers: item.Peers, poster_url: item.Banner || null,
        genres: [], description: item.Description || '', imdb_rating: null
      }]).select().single();

      // Аудио из названия
      let codec = 'AAC', channels = '2.0', language = 'rus', studio = null;
      if (lower.includes('atmos') || lower.includes('truehd')) codec = 'Dolby Atmos/TrueHD';
      else if (lower.includes('dts')) codec = 'DTS-HD';
      else if (lower.includes('ac3') || lower.includes('dd5')) codec = 'AC3';
      if (lower.includes('7.1') || lower.includes('8ch')) channels = '7.1';
      else if (lower.includes('5.1') || lower.includes('6ch')) channels = '5.1';
      else if (lower.includes('mono')) channels = 'mono';
      const studios = ['lostfilm', 'newstudio', 'hdrezka', 'jaskier', 'anidub', 'alexfilm', 'sonyahouse'];
      for (const s of studios) if (lower.includes(s)) { studio = s; break; }
      if (lower.includes('sub')) language = 'rus_sub';
      else if (lower.includes('eng')) language = 'eng';

      await supabase.from('audio_tracks').insert([{
        content_id: content.id, language, codec, channels, studio, is_default: language === 'rus'
      }]);
      console.log(`✅ Добавлен: ${title}`);
    }
  } catch (e) { console.error('❌ Ошибка парсера:', e.message); }
}

if (process.env.ENABLE_CRON === 'true') {
  cron.schedule('0 */6 * * *', runParser);
}

// ===== SPA FALLBACK =====
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// ===== ЗАПУСК =====
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🎬 StreamHub запущен на порту ${PORT}`);
  console.log(`📡 WebTorrent активен, торрентов в памяти: ${wtClient.torrents.length}`);
});
