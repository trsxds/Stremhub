-- StreamHub Database Schema

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  watching UUID[] DEFAULT '{}',
  watched UUID[] DEFAULT '{}',
  watchlist UUID[] DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS content (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  type TEXT CHECK (type IN ('movie', 'series', 'anime')),
  year INTEGER,
  genres TEXT[] DEFAULT '{}',
  quality TEXT CHECK (quality IN ('4K', '1080p', '720p', 'unknown')),
  magnet_link TEXT,
  torrent_url TEXT,
  size BIGINT,
  seeders INTEGER DEFAULT 0,
  peers INTEGER DEFAULT 0,
  poster_url TEXT,
  description TEXT,
  imdb_rating DECIMAL(3,1),
  imdb_id TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audio_tracks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id UUID REFERENCES content(id) ON DELETE CASCADE,
  language TEXT,
  codec TEXT,
  channels TEXT,
  studio TEXT,
  is_default BOOLEAN DEFAULT false
);

CREATE TABLE IF NOT EXISTS subtitles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id UUID REFERENCES content(id) ON DELETE CASCADE,
  language TEXT,
  format TEXT CHECK (format IN ('SRT', 'ASS', 'VTT')),
  url TEXT
);

CREATE TABLE IF NOT EXISTS activity_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  content_id UUID REFERENCES content(id) ON DELETE CASCADE,
  action TEXT,
  quality TEXT,
  studio TEXT,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS friendships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  friend_id UUID REFERENCES users(id) ON DELETE CASCADE,
  status TEXT CHECK (status IN ('pending', 'accepted')),
  invite_code TEXT UNIQUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_content_type ON content(type);
CREATE INDEX IF NOT EXISTS idx_content_quality ON content(quality);
CREATE INDEX IF NOT EXISTS idx_content_year ON content(year);
CREATE INDEX IF NOT EXISTS idx_content_title ON content USING gin(to_tsvector('russian', title));
CREATE INDEX IF NOT EXISTS idx_activity_timestamp ON activity_log(timestamp DESC);

-- RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE friendships ENABLE ROW LEVEL SECURITY;

CREATE POLICY "public_content" ON content FOR SELECT USING (true);
CREATE POLICY "own_profile" ON profiles FOR ALL USING (user_id = auth.uid());
CREATE POLICY "own_activity" ON activity_log FOR ALL USING (user_id = auth.uid());
CREATE POLICY "own_friends" ON friendships FOR ALL USING (user_id = auth.uid() OR friend_id = auth.uid());
